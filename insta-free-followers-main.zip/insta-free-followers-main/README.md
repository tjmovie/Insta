

# Instagram Free Followers
Get from 1000 to 5000 free followers / day with this Instagram account generator bot. 

You just need to install the modules and run the [Python](https://python.org) script 
