from insta impot accounts 
from instabot import sub, antiban
from time import *
from os import *
from instagramAPI import request 

account = "[insta.account/avatar/post/#]
sub = "inputed.user.username"
time = "time.sleep(0.3"

sub = input("Please insert your usernme without the @ >")

while True: 
  account.request=1
  sub.request=sub 
  time()
  
  
 # This will generate an account, follow your Instagram and loop it. 

while sub<5000:
  time.sleep("24H")
  antiban.on 
  run.loop()
  
 # You have free antiban under 5000 followers a day. Over this its at your own risks. 
  
